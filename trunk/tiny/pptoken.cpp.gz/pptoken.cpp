#include <iostream>
#include <sstream>
#include <fstream>
#include <stdexcept>
#include <algorithm>
#include <unordered_map>
#include <unordered_set>

#include <cstdint>

using namespace std;

#include "IPPTokenStream.h"
#include "DebugPPTokenStream.h"

// Translation features you need to implement:
// - utf8 decoder
// - utf8 encoder
// - universal-character-name decoder
// - trigraphs
// - line splicing
// - newline at eof
// - comment striping (can be part of whitespace-sequence)

// EndOfFile: synthetic "character" to represent the end of source file
constexpr int EndOfFile = -1;

// given hex digit character c, return its value
int HexCharToValue(int c)
{
	switch (c)
	{
	case '0': return 0;
	case '1': return 1;
	case '2': return 2;
	case '3': return 3;
	case '4': return 4;
	case '5': return 5;
	case '6': return 6;
	case '7': return 7;
	case '8': return 8;
	case '9': return 9;
	case 'A': return 10;
	case 'a': return 10;
	case 'B': return 11;
	case 'b': return 11;
	case 'C': return 12;
	case 'c': return 12;
	case 'D': return 13;
	case 'd': return 13;
	case 'E': return 14;
	case 'e': return 14;
	case 'F': return 15;
	case 'f': return 15;
	default: throw logic_error("HexCharToValue of nonhex char");
	}
}

// See C++ standard 2.11 Identifiers and Appendix/Annex E.1
const vector<pair<int, int>> AnnexE1_Allowed_RangesSorted =
{
	{0xA8,0xA8},
	{0xAA,0xAA},
	{0xAD,0xAD},
	{0xAF,0xAF},
	{0xB2,0xB5},
	{0xB7,0xBA},
	{0xBC,0xBE},
	{0xC0,0xD6},
	{0xD8,0xF6},
	{0xF8,0xFF},
	{0x100,0x167F},
	{0x1681,0x180D},
	{0x180F,0x1FFF},
	{0x200B,0x200D},
	{0x202A,0x202E},
	{0x203F,0x2040},
	{0x2054,0x2054},
	{0x2060,0x206F},
	{0x2070,0x218F},
	{0x2460,0x24FF},
	{0x2776,0x2793},
	{0x2C00,0x2DFF},
	{0x2E80,0x2FFF},
	{0x3004,0x3007},
	{0x3021,0x302F},
	{0x3031,0x303F},
	{0x3040,0xD7FF},
	{0xF900,0xFD3D},
	{0xFD40,0xFDCF},
	{0xFDF0,0xFE44},
	{0xFE47,0xFFFD},
	{0x10000,0x1FFFD},
	{0x20000,0x2FFFD},
	{0x30000,0x3FFFD},
	{0x40000,0x4FFFD},
	{0x50000,0x5FFFD},
	{0x60000,0x6FFFD},
	{0x70000,0x7FFFD},
	{0x80000,0x8FFFD},
	{0x90000,0x9FFFD},
	{0xA0000,0xAFFFD},
	{0xB0000,0xBFFFD},
	{0xC0000,0xCFFFD},
	{0xD0000,0xDFFFD},
	{0xE0000,0xEFFFD}
};

// See C++ standard 2.11 Identifiers and Appendix/Annex E.2
const vector<pair<int, int>> AnnexE2_DisallowedInitially_RangesSorted =
{
	{0x300,0x36F},
	{0x1DC0,0x1DFF},
	{0x20D0,0x20FF},
	{0xFE20,0xFE2F}
};

// See C++ standard 2.13 Operators and punctuators
const unordered_set<string> Digraph_IdentifierLike_Operators =
{
	"new", "delete", "and", "and_eq", "bitand",
	"bitor", "compl", "not", "not_eq", "or",
	"or_eq", "xor", "xor_eq"
};

// See `simple-escape-sequence` grammar
const unordered_set<int> SimpleEscapeSequence_CodePoints =
{
	'\'', '"', '?', '\\', 'a', 'b', 'f', 'n', 'r', 't', 'v'
};

struct Translator
{
	string& input;

	Translator(string& input)
		: input(input)
	{}

	void Translate()
	{
		if(input.length() > 0 && *input.rbegin() != '\n') {
			input.append(1, '\n');
		}
	}
};

// Tokenizer
struct PPTokenizer
{
	enum TokenType { NONE, IDENTIFIER, CHAR_LITERAL, COMMENT_C, COMMENT_CPP,
		WHITESPACE, NUMBER, PUNC, STRING } tokenType = NONE;

	IPPTokenStream& output;
	string s;

	PPTokenizer(IPPTokenStream& output)
		: output(output)
	{}

	bool is_punc_starter(char c) {
		for(auto const& x : (char[]) { '{', '}', '[', ']', '#', '(', ')', '<', '>', '%', ';', ':', '.', '?', '+', '-', '*', '/', '^', '&', '|', '~', '!', '=', ',' }) {
			if(c == x) {
				return true;
			}
		}
		return false;
	}

	bool is_punc(string s) {
		for(auto const& x : { 
					 "{", "}", "[", "]", "#", "##", "(", ")", "<:", ":>", "<%", "%>", "%:", "%:%:", ";", ":", "...",
					    "new", "delete", "?", "::", ".", ".*", "+", "-", "*", "/", "%", "ˆ", "&", "|", "~", "!", "=", "<", ">",
					    "+=", "-=", "*=", "/=", "%=", "ˆ=", "&=", "|=", "<<", ">>", ">>=", "<<=", "<=", ">=", "&&", "==", "!=",
					    "||", "++", "--", ",", "->*", "->", "and", "and_eq", "bitand", "bitor", "compl",
					    "not", "not_eq", "or", "or_eq", "xor", "xor_eq"
				}) {
			if(s == x) {
				return true;
			}
		}
		return false;
	}

	void process(int c)
	{
		if(tokenType == NONE) {
			if(isalpha(c) || c == '_') {
				tokenType = IDENTIFIER; s = ""; process(c);
			} else if(isdigit(c) || c == '.') {
				tokenType = NUMBER; s = ""; process(c);
			} else if(c == '\'') {
				tokenType = CHAR_LITERAL; s = ""; process(c);
			} else if(c == '"') {
				tokenType = STRING; s = ""; process(c);
			} else if(c == EndOfFile) {
				output.emit_eof(); s = "";
			} else if(c == '\n') { 
				output.emit_new_line(); s = "";
			} else if(c == ' ') {
				tokenType = WHITESPACE; s = ""; process(c);
			} else if(s == "/*") {
				tokenType = COMMENT_C;
			} else if(s == "//") {
				tokenType = COMMENT_CPP;
			} else if(is_punc_starter(c)) {
				tokenType = PUNC; s = ""; process(c);
			} else { 
				s.append(1, c);
			}

		} else if(tokenType == IDENTIFIER) {
			if(s.length() == 1 && c == '\'' 
			&& (s[0] == 'u' || s[0] == 'U' || s[0] == 'L')) {
				tokenType = CHAR_LITERAL;
				s.append(1, c);
				//process(c);
			} else if(!isalpha(c) && c != '_' && !isdigit(c)) {
				output.emit_identifier(s); s = "";
				tokenType = NONE;
				process(c);
			} else {
				s.append(1, c);
			}

		} else if(tokenType == NUMBER) {
			if(isdigit(c) || c == '.' || c == 'e' || c == 'E') {
				s.append(1, c);
			} else if(s.length() > 0 && (*s.rbegin() == 'e' || *s.rbegin() == 'E') && (c == '+' || c == '-')) {
				s.append(1, c);
			} else {
				output.emit_pp_number(s);
				tokenType = NONE;
				process(c);
			}

		} else if(tokenType == CHAR_LITERAL) {
			if(s.length() > 0 && c == '\'') {
				s.append(1, c);
				output.emit_character_literal(s); s = "";
				tokenType = NONE;
			}
			else if(c == '\\' || c == '\n') {
				output.emit_character_literal(s); s = "";
				tokenType = NONE;
				process(c);
			} else {
				s.append(1, c);
			}
		
		} else if(tokenType == STRING) {
			if(s.length() > 0 && c == '"') {
				s.append(1, c);
				output.emit_character_literal(s); s = "";
				tokenType = NONE;
			} else {
				s.append(1, c);
			}
		
		} else if(tokenType == COMMENT_C) {
			if(*s.rbegin() == '*' && c == '/') {
				output.emit_whitespace_sequence(); s = "";
				tokenType = NONE;
				process(c);
			} else {
				s.append(1, c);
			}

		} else if(tokenType == COMMENT_CPP) {
			if(c == '\n') {
				output.emit_whitespace_sequence(); s = "";
				tokenType = NONE;
				process(c);
			}

		} else if(tokenType == WHITESPACE) { 
			if(c != ' ') {
				output.emit_whitespace_sequence(); s = "";
				tokenType = NONE;
				process(c);
			}

		} else if(tokenType == PUNC) {
			string x(s);
			x.append(1, c);
			if(x == "/*") {
				tokenType = COMMENT_C; process(c);
			} else if(x == "//") {
				tokenType = COMMENT_CPP; process(c);
			} else if(is_punc(x)) { 
			} else if(is_punc(s)) {
				output.emit_preprocessing_op_or_punc(s); s = "";
				tokenType = NONE;
				process(c);
			}
			s.append(1, c);
		}
	}
};

int main()
{
	try
	{
		ostringstream oss;
		oss << cin.rdbuf();

		string input = oss.str();
		Translator(input).Translate();

		DebugPPTokenStream output;

		PPTokenizer tokenizer(output);

		for (char c : input)
		{
			unsigned char code_unit = c;
			tokenizer.process(code_unit);
		}

		tokenizer.process(EndOfFile);
	}
	catch (exception& e)
	{
		cerr << "ERROR: " << e.what() << endl;
		return EXIT_FAILURE;
	}
}

