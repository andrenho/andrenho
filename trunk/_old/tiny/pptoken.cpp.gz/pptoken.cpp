#include <iostream>
#include <sstream>
#include <fstream>
#include <stdexcept>
#include <algorithm>
#include <unordered_map>
#include <unordered_set>

#include <cassert>
#include <cstdint>

using namespace std;

#include "IPPTokenStream.h"
#include "DebugPPTokenStream.h"

// Translation features you need to implement:
// - utf8 decoder
// - utf8 encoder
// - universal-character-name decoder
// - trigraphs
// - line splicing
// - newline at eof
// - comment striping (can be part of whitespace-sequence)

// EndOfFile: synthetic "character" to represent the end of source file
constexpr int EndOfFile = -1;

// given hex digit character c, return its value
int HexCharToValue(int c)
{
	switch (c)
	{
	case '0': return 0;
	case '1': return 1;
	case '2': return 2;
	case '3': return 3;
	case '4': return 4;
	case '5': return 5;
	case '6': return 6;
	case '7': return 7;
	case '8': return 8;
	case '9': return 9;
	case 'A': return 10;
	case 'a': return 10;
	case 'B': return 11;
	case 'b': return 11;
	case 'C': return 12;
	case 'c': return 12;
	case 'D': return 13;
	case 'd': return 13;
	case 'E': return 14;
	case 'e': return 14;
	case 'F': return 15;
	case 'f': return 15;
	default: throw logic_error("HexCharToValue of nonhex char");
	}
}

// See C++ standard 2.11 Identifiers and Appendix/Annex E.1
const vector<pair<int, int>> AnnexE1_Allowed_RangesSorted =
{
	{0xA8,0xA8},
	{0xAA,0xAA},
	{0xAD,0xAD},
	{0xAF,0xAF},
	{0xB2,0xB5},
	{0xB7,0xBA},
	{0xBC,0xBE},
	{0xC0,0xD6},
	{0xD8,0xF6},
	{0xF8,0xFF},
	{0x100,0x167F},
	{0x1681,0x180D},
	{0x180F,0x1FFF},
	{0x200B,0x200D},
	{0x202A,0x202E},
	{0x203F,0x2040},
	{0x2054,0x2054},
	{0x2060,0x206F},
	{0x2070,0x218F},
	{0x2460,0x24FF},
	{0x2776,0x2793},
	{0x2C00,0x2DFF},
	{0x2E80,0x2FFF},
	{0x3004,0x3007},
	{0x3021,0x302F},
	{0x3031,0x303F},
	{0x3040,0xD7FF},
	{0xF900,0xFD3D},
	{0xFD40,0xFDCF},
	{0xFDF0,0xFE44},
	{0xFE47,0xFFFD},
	{0x10000,0x1FFFD},
	{0x20000,0x2FFFD},
	{0x30000,0x3FFFD},
	{0x40000,0x4FFFD},
	{0x50000,0x5FFFD},
	{0x60000,0x6FFFD},
	{0x70000,0x7FFFD},
	{0x80000,0x8FFFD},
	{0x90000,0x9FFFD},
	{0xA0000,0xAFFFD},
	{0xB0000,0xBFFFD},
	{0xC0000,0xCFFFD},
	{0xD0000,0xDFFFD},
	{0xE0000,0xEFFFD}
};

// See C++ standard 2.11 Identifiers and Appendix/Annex E.2
const vector<pair<int, int>> AnnexE2_DisallowedInitially_RangesSorted =
{
	{0x300,0x36F},
	{0x1DC0,0x1DFF},
	{0x20D0,0x20FF},
	{0xFE20,0xFE2F}
};

// See C++ standard 2.13 Operators and punctuators
const unordered_set<string> Digraph_IdentifierLike_Operators =
{
	"new", "delete", "and", "and_eq", "bitand",
	"bitor", "compl", "not", "not_eq", "or",
	"or_eq", "xor", "xor_eq"
};

const unordered_set<string> preproc = 
{
	"{", "}", "[", "]", "#", "##", "(", ")", "<:", ":>", "<%", "%>", "%:", 
	"%:%:", ";", ":", "...", "?", "::", ".", ".*", "+", "-", "*", "/", "%", 
	"^", "&", "|", "~", "!", "=", "<", ">", "+=", "-=", "*=", "/=", "%=", 
	"^=", "&=", "|=", "<<", ">>", ">>=", "<<=", "<=", ">=", "&&", "==", 
	"!=", "||", "++", "--", ",", "->*", "->"
};

// See `simple-escape-sequence` grammar
const unordered_set<int> SimpleEscapeSequence_CodePoints =
{
	'\'', '"', '?', '\\', 'a', 'b', 'f', 'n', 'r', 't', 'v'
};

struct Translator
{
	string& input;

	Translator(string& input)
		: input(input)
	{}

	void Translate() {
		Trigraphs();
		JoinLines();
		AddLastEnter();
		RemoveComments();
	}

	void Trigraphs() {
		string s;
		for(unsigned int i=0; i<input.length(); ++i) {
			if(i > input.length() - 2) {
				s.append(1, input[i]);
			} else if(input[i] == '?' && input[i+1] == '?') {
				switch(input[i+2]) {
				case '=': s += "#"; i+=2; break;
				case '/': s += "\\"; i+=2; break;
				case '\'': s += "^"; i+=2; break;
				case '(': s += "["; i+=2; break;
				case ')': s += "]"; i+=2; break;
				case '!': s += "|"; i+=2; break;
				case '<': s += "{"; i+=2; break;
				case '>': s += "}"; i+=2; break;
				case '-': s += "~"; i+=2; break;
				default:
					 s.append(1, input[i]);
				}
			} else {
				s.append(1, input[i]);
			}
		}
		input.assign(s);
	}

	void RemoveComments() {
		string s;
		enum { NO, C, CPP } commentType = NO;
		for(unsigned int i=0; i<input.length(); ++i) {
			if(commentType == NO) {
				if(input[i] == '/' && input[i+1] == '*') {
					commentType = C;
				} else if(input[i] == '/' && input[i+1] == '/') {
					commentType = CPP;
				} else {
					s.append(1, input[i]);
				}
			} else if(commentType == C) {
				if(input[i-1] == '*' && input[i] == '/') {
					s.append(1, ' ');
					commentType = NO;
				}
			} else if(commentType == CPP) {
				if(input[i] == '\n') {
					s.append(1, ' ');
					s.append(1, input[i]);
					commentType = NO;
				}
			}
		}
		if(commentType == C) {
			throw new exception();
		}
		input.assign(s);
	}

	void JoinLines() {
		string s;
		if(!input.empty()) {
			s.append(1, input[0]);
		}
		for(unsigned int i=1; i<input.length(); ++i) {
			if(input[i] == '\\' && input[i+1] == '\n') {
				++i;
			} else {
				s.append(1, input[i]);
			}
		}
		input.assign(s);
	}

	void AddLastEnter() {
		if(!input.empty() && *input.rbegin() != '\n') {
			input.append(1, '\n');
		}
	}
};

// Tokenizer
struct PPTokenizer
{
	enum State { A='A', B, C, D, E, F, G, H, I, J, K, L, M, N, START, 
		P, Q, R } state = START;

	IPPTokenStream& output;
	string s = "", rawseq = "";
	bool afterInclude = false;
	bool userString = false;

	PPTokenizer(IPPTokenStream& output)
		: output(output)
	{}

	void setState(enum State st, int c) {
		s.append(1, c);
		state = st;
		afterInclude = false;
	}

	void setSTART(int c, bool advance=false) {
		state = START;
		s = "";
		afterInclude = false;
		if(!advance) {
			process(c);
		}
	}

	void process(int c)
	{
		//cout << "Lookahead: " << (char)c << " (" << c << ")  State: " << (char)state << "  String: " << s << endl;
		switch(state) {
		case START:
			if(c == '\'') {
				setState(F, c);
			} else if(c == 'u') {
				setState(H, c);
			} else if(c == '"' && !afterInclude) {
				setState(G, c);
			} else if(c == 'U' || c == 'L') {
				setState(A, c);
			} else if(c == 'R') {
				setState(B, c);
			} else if(isalpha(c) || c == '_') {
				setState(C, c);
			} else if(isdigit(c)) {
				setState(D, c);
			} else if(is_preproc_first_char(c)) {
				setState(J, c);
			} else if(c == '<') {
				setState(K, c);
			} else if(c == '"' && afterInclude) {
				setState(M, c);
			} else if(c == ' ') {
				output.emit_whitespace_sequence();
			} else if(c == '\n') {
				output.emit_new_line();
			} else if(c == -1) {
				output.emit_eof();
			} else {
				string v;
				v.append(1, c);
				output.emit_non_whitespace_char(v);
			}
			break;
		case A: 
			if(c == '\'') {
				setState(F, c);
			} else if(c == '"') {
				setState(G, c);
			} else {
				setState(C, c);
			}
			break;
		case B:
			if(c == '\"') {
				setState(P, c);
			} else {
				setState(C, c);
			}
			break;
		case C:
			if(isalnum(c) || c == '_') { // TODO - preprocessor
				s.append(1, c);
			} else {
				if(is_preproc(s)) {
					output.emit_preprocessing_op_or_punc(s);
				} else if(userString) {
					userString = false;
					output.emit_user_defined_string_literal(s);
				} else {
					output.emit_identifier(s);
				}
				setSTART(c);
			}
			break;
		case D:
			if(c == 'e' || c == 'E') {
				setState(E, c);
			} else if(isalnum(c) || c == '_' || c == '.') {
				s.append(1, c);
			} else {
				output.emit_pp_number(s);
				setSTART(c);
			}
			break;
		case E:
			/*
			if(c == '+' || c == '-') {
				s.append(1, c);
				output.emit_pp_number(s);
				setSTART(c, true);
			} else { */
				setState(D, c);
			//}
			break;
		case F:
			if(c == '\n') {
				throw new exception();
			} else if(c == '\'' && !s.empty() && s != "u" && s != "U" && s != "L") {
				s.append(1, c);
				output.emit_character_literal(s);
				setSTART(c, true);
			} else {
				s.append(1, c);
			}
			break;
		case G:
			if(c == '\n') {
				throw new exception();
			} else if(c == '"' && !s.empty() && s != "u" && s != "U" && s != "L" && s != "u8") {
				setState(R, c);
			} else {
				s.append(1, c);
			}
			break;
		case H: 
			if(c == '\'') {
				setState(F, c);
			} else if(c == '8') {
				setState(I, c);
			} else if(c == '"') {
				setState(G, c);
			} else {
				setState(C, c);
			}
			break;
		case I:
			if(c == '"') {
				setState(G, c);
			} else {
				setState(C, c);
			}
			break;
		case J:
			if(s == "<:" && c == ':') {
				output.emit_preprocessing_op_or_punc("<");
				output.emit_preprocessing_op_or_punc("::");
				setSTART(c, true);
			} else if(next_is_preproc(s, c)) {
				s.append(1, c);
			} else {
				output.emit_preprocessing_op_or_punc(s);
				setSTART(c);
			}
			break;
		case K:
			if(next_is_preproc(s, c)) {
				setState(J, c);
			} else if(c == '\n' || c == '>') {
				throw new exception();
			} else {
				setState(L, c);
			}
			break;
		case L:
			if(c == '>') {
				s.append(1, c);
				output.emit_header_name(s);
				setSTART(c, true);
			} else {
				s.append(1, c);
			}
			break;
		case M:
			if(c == '\n' || c == '"') {
				throw new exception();
			} else {
				setState(N, c);
			}
			break;
		case N:
			if(c == '"') {
				s.append(1, c);
				output.emit_header_name(s);
				setSTART(c, true);
			} else {
				s.append(1, c);
			}
			break;
		case P:
			if(c == '(') {
				rawseq.assign(s, 2, string::npos);
				setState(Q, c);
			} else if(c == ' ' || c == ')' || c == '\n' || c == '\t' || c == '\f' || c == '\v') {
				throw new exception();
			} else {
				s.append(1, c);
			}
			break;
		case Q:
			s.append(1, c);
			{
				string cmp = ")" + rawseq + "\"";
				if(s.compare(s.length()-cmp.length(), string::npos, cmp) == 0) {
					rawseq = "";
					output.emit_string_literal(s);
					setSTART(c, true);
				}
			}
			break;
		case R:
			if(isalpha(c) || c == '_') {
				userString = true;
				setState(C, c);
			} else {
				output.emit_string_literal(s);
				setSTART(c);
			}
			break;
		}
	}


	bool is_preproc_first_char(int c) {
		for(auto const& s: preproc) {
			if(s[0] == (char)c) {
				return true;
			}
		}
		return false;
	}


	bool is_preproc_char(int c) {
		for(auto const& s: preproc) {
			if(s.find((char)c) != string::npos) {
				return true;
			}
		}
		return false;
	}

	bool is_preproc(string& st) {
		for(auto const& v: preproc) {
			if(v == st) {
				return true;
			}
		}
		for(auto const& v: Digraph_IdentifierLike_Operators) {
			if(v == st) {
				return true;
			}
		}
		return false;
	}

	bool next_is_preproc(string st, char c) {
		st.append(1, c);
		for(auto const& v: preproc) {
			if(v.length() >= st.length()) {
				if(v.compare(0, st.length(), st) == 0) {
					return true;
				}
			}
		}
		return false;
	}
};

int main()
{
	try
	{
		ostringstream oss;
		oss << cin.rdbuf();

		string input = oss.str();
		Translator(input).Translate();

		DebugPPTokenStream output;

		PPTokenizer tokenizer(output);

		for (char c : input)
		{
			unsigned char code_unit = c;
			tokenizer.process(code_unit);
		}

		tokenizer.process(EndOfFile);
	}
	catch (exception& e)
	{
		cerr << "ERROR: " << e.what() << endl;
		return EXIT_FAILURE;
	}
}

